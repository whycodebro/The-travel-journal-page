import React from "react"
import Navbar from "./Navbar"
import Places from "./Places"
import data from "./data"


export default function App() {
    
    const placeElements = data.map( place => {
        return <Places 
                    imageUrl={place.imageUrl}
                    location={place.location}
                    googleMapsUrl={place.googleMapsUrl} 
                    title={place.title}
                    startDate={place.startDate}
                    endDate={place.endDate}
                    description={place.description} />    
    } )
    return(
        <div>
            <Navbar />
            <section>
                {placeElements}
            </section>
            
        </div>
    )

}