import React from "react"

export default function Navbar() {
    return (
        <p className="navbar--title" > my travel journal </p>
    )
}