import React from "react"

export default function Places(props) {
    return (
        
         
         <div className="place--div1"  >
            console.log(props)
            <img src = {props.imageUrl} className="place--img" />
            <div className="place--div2"  >
                <img src="./download.png" className="location--img" />
                <span className="place--country">{props.location} </span>
                <a href={props.googleMapsUrl}>View on Google Maps </a>
                <h1 className="place--title" > {props.title} </h1>
                <p className="place--date" > {props.startDate} - {props.endDate} </p>
                <p className="place--desc" >{props.description}</p>
            </div>
         </div>
    )
}